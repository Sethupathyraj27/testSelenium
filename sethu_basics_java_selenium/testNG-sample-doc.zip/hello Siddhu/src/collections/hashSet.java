package collections;

import java.util.HashSet;

public class hashSet {
public static void main(String[] args) {
	HashSet <String> h = new HashSet <String>(); 
		h.add("1");
		h.add("10");
		h.add("10.1");
		h.add("100");
		h.add("1000");
		h.add("10000");
		h.add("10.2");
		
//		System.out.println(h.size());
		
		System.out.println(h);
		
//		h.remove("ibm");
//		System.out.println(h);
}
}
