
public class methods {
void anandh(){
	System.out.println("anandh method");
}
void anandh2(){
	System.out.println("anandh method");
}
void anandh3(){
	System.out.println("anandh method");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methods abc = new methods();
		methods abcd = new methods();
		abc.anandh();
		abcd.anandh2();
		abc.anandh3();
}
}
