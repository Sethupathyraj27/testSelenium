package dashboard;

public class sidJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.print("siddhu");
		int a=13;
		int b=12;
		int c = a+     b;      /* Concatenation int */
		
		
		System.out.println(a+b);
		
		String a1="anand";
		String b1="anand2";
		System.out.println(a1+" "+b1);    /* Concatenation string*/
		
		System.out.println(a1.concat(b1));
		
		char a2=' ';
		char b2='4';
		System.out.println(a2+" "+b2);   /* Concatenation char*/
		
	
		
		float fl=0.4f;
		float fl2=9.5555554f;
		int fl3=1;
		System.out.println(fl+fl2+fl3+" test float");    /* Concatenation float*/
		
		String javaString="anand kumar";
		String javaString2="anand kumar";
	
		System.out.println(javaString.length());   /* length ---number of characters or letters in the variable*/
		
	System.out.println(javaString.equals(javaString2));   /* equals*/
//	if(javaString==javaString2) {
//		System.out.println("both vaa are equal");
//	}
	
	System.out.println(javaString.concat(javaString2));   /* concatenation */
	
	System.out.println(a1.charAt(3));     /* charAt - position checking */

	String indexOfCheck="true this is true";
	
		System.out.println(indexOfCheck.indexOf("e"));  /* index of - position checking */
		
		
		
		
	}
	}


