package basicPrograms;

import java.util.HashMap;
import java.util.LinkedHashSet;


public class linkedHashSet_duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<String> al=new LinkedHashSet<String>();  
//		  al.add("Ravi");  
//		  al.add("Vijay");  
//		  al.add("Ravi");  
//		  al.add("Ravi");  
//		  al.add("Ravi");  
//		  al.add("Ravi");  
//		  al.add("Ravi");  
//		  al.add("Ajay"); 
//		  al.add("Ajay"); 
//		  al.add("Ajay"); 
				  
		  System.out.println(al);
		  
		  LinkedHashSet <Integer> var = new LinkedHashSet <Integer>();
		  var.add(1);
		  var.add(1);
		  var.add(1);
		  var.add(1);
		  var.add(2);
		  System.out.println(var);
		  
		  String s="siddharth";
		  LinkedHashSet<Character>s2=new LinkedHashSet<Character>();
		 s2.add(s.charAt(0));
		 s2.add(s.charAt(1));
		 s2.add(s.charAt(2));
		 s2.add(s.charAt(3));
		 s2.add(s.charAt(4));
		 s2.add(s.charAt(5));
		 s2.add(s.charAt(6));
		 s2.add(s.charAt(7));
		 s2.add(s.charAt(8));
		 System.out.println(s2);
		 
		 
		 
		  
		
	}

}
