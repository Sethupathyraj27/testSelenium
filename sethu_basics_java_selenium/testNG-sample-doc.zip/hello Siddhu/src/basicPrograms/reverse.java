package basicPrograms;

public class reverse {
public static void main(String[] args) {
//	String myName="anandh";
//	StringBuffer myName2= new StringBuffer(myName);
//	myName2.reverse();
//	System.out.println(myName2);
	
	
	
	String a="siddhu";
	StringBuffer a1=new StringBuffer(a);
	
	a1.reverse();
	
	System.out.println(a1);
	
	
	
}
}
