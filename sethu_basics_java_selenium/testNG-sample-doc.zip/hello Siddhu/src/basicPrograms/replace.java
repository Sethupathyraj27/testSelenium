package basicPrograms;

public class replace {
public static void main(String[] args) {
	String name = "siddhu";
	String name2=name.replace("siddhu", "sidharth");
	System.out.println(name2);
}
}
