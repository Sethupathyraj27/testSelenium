package basicPrograms;

public class screenShot {
public static void main(String[] args) {
	
}
}
