package basicPrograms;

public class javaTrim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String anand = "   anand and siddharth        ";
System.out.println(anand);
System.out.println(anand.trim());

String var1="anandaaaaaaaa";
String var2=var1.replace("a", "b");
System.out.println(var2);

	}

}
