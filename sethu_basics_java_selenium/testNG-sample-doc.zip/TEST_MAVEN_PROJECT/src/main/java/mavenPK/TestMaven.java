package mavenPK;

import org.testng.annotations.Test;

public class TestMaven {
@Test
public void ragav() {
	System.out.println("ragav testNG class works");
}

}

