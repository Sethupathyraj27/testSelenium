package pageObjects;

public class Login_POM {

}
