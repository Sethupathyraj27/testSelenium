package testCases;

import org.testng.annotations.Test;

import commonFunctions.CommonFunctions;

public class Test_UserRole extends CommonFunctions{
	@Test
	public void testUserRole() {
		System.out.println("test user");
	}
}
