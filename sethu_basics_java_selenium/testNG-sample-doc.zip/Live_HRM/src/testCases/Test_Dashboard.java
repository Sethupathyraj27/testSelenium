package testCases;

import org.testng.annotations.Test;

import commonFunctions.CommonFunctions;

public class Test_Dashboard extends CommonFunctions{
@Test
public void testClass() {
	System.out.println("test dash");
}
}
