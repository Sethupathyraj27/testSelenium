package testCase;

import org.testng.annotations.Test;

import commonFun.CommonFunctions;

public class Test_User extends CommonFunctions {
	@Test
	public void check() throws InterruptedException {
//		Thread.sleep(5000);
		System.out.println("testUserClass");
		System.out.println("checkUser");
	}
}
