package testCase;

import org.testng.annotations.Test;

import commonFun.CommonFunctions;

public class Test_Dashboard extends CommonFunctions{
	@Test
	public void check() throws InterruptedException {
//		Thread.sleep(5000);
		System.out.println("checkDashboard");
	}
}
