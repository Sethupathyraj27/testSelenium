package enCap;

public class eCap2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		enCap1 a = new enCap1();
		a.setname("ragav");
		a.setSNO(10);
		a.setMark(45);
		
	System.out.println(a.getName()+","+a.getSNO()+","+a.getMark());
	}

}


//procedure;

// 1. same pakage multiple java class files
//2. make private variables on 1st class
//3. get variables for all
//4. set variables for all
//5. create object with the name of 1st class
//6. on second file set variables and print it