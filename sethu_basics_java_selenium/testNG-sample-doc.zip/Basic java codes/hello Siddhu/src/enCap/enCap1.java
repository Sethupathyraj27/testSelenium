package enCap;

public class enCap1 {

	private String name;
	private int sNo;
	private int mark;
	
	public String getName(){
		return name;
	}
	
	public int getSNO(){
		return sNo;
	}
	
	
	public int getMark(){
		return mark;
	}
	
	
	public void setname(String name2){
		name=name2;
	}
	
public void setSNO(int sNo2){
		sNo=sNo2;
	}

public void setMark(int mark2){
	mark=mark2;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
