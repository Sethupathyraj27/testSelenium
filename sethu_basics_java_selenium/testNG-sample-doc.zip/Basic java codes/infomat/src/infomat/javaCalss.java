//test     
package infomat;

public class javaCalss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String siddhuFriends[]={"anand","arun","ragav","parthSir"};
		System.out.println(siddhuFriends[2]+ " is my friend");
		
		for (int ind = 0;ind<siddhuFriends.length;ind++){
			System.out.println(siddhuFriends[ind]);
		}
		
		int a=5;
		while (a<=15){
			System.out.println("value of a is "+a);
			a++;
		}
	}

}


