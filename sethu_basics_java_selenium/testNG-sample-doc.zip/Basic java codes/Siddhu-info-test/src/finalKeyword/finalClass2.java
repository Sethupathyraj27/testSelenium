package finalKeyword;

public class finalClass2 extends finalClass {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
finalClass m3 = new finalClass();
m3.method1();
m3.method2();


	}

}
