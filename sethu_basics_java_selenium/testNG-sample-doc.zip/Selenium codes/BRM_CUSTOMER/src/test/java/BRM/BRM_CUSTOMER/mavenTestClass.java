package BRM.BRM_CUSTOMER;

public class mavenTestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
