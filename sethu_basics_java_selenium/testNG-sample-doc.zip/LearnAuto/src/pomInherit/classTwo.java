package pomInherit;
//inherit one class file's method from another class

public class classTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(classOne.method1());		
	}

}
