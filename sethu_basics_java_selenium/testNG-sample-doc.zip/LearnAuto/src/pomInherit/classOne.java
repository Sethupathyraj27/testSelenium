package pomInherit;

public class classOne {

	public static String method1() {
		String a="10+5";
		return a;
	}

}
